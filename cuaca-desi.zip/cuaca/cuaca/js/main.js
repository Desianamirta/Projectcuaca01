(function($) {
  "use strict";
  $(window).on("load", function() { // makes sure the whole site is loaded
    //preloader
    $("#status").fadeOut(); // will first fade out the loading animation
    $("#preloader").delay(450).fadeOut("slow"); // will fade out the white DIV that covers the website.
    
    //masonry
    $('.grid').masonry({
      itemSelector: '.grid-item'
      
    });    
  });


  $(document).ready(function(){  

    //active menu
    $(document).on("scroll", onScroll);
 
    $('a[href^="#"]').on('click', function (e) {
      e.preventDefault();
      $(document).off("scroll");
 
      $('a').each(function () {
        $(this).removeClass('active');
      })
      $(this).addClass('active');
 
      var target = this.hash;
      $target = $(target);
      $('html, body').stop().animate({
        'scrollTop': $target.offset().top+2
      }, 500, 'swing', function () {
        window.location.hash = target;
        $(document).on("scroll", onScroll);
      });
    });

    
    //scroll js
    smoothScroll.init({
      selector: '[data-scroll]', // Selector for links (must be a valid CSS selector)
      selectorHeader: '[data-scroll-header]', // Selector for fixed headers (must be a valid CSS selector)
      speed: 500, // Integer. How fast to complete the scroll in milliseconds
      easing: 'easeInOutCubic', // Easing pattern to use
      updateURL: true, // Boolean. Whether or not to update the URL with the anchor hash on scroll
      offset: 0, // Integer. How far to offset the scrolling anchor location in pixels
      callback: function ( toggle, anchor ) {} // Function to run after scrolling
    });

    //menu
    var bodyEl = document.body,
    content = document.querySelector( '.content-wrap' ),
    openbtn = document.getElementById( 'open-button' ),
    closebtn = document.getElementById( 'close-button' ),
    isOpen = false;

    function inits() {
      initEvents();
    }

    function initEvents() {
      openbtn.addEventListener( 'click', toggleMenu );
      if( closebtn ) {
        closebtn.addEventListener( 'click', toggleMenu );
      }

      // close the menu element if the target it´s not the menu element or one of its descendants..
      content.addEventListener( 'click', function(ev) {
        var target = ev.target;
        if( isOpen && target !== openbtn ) {
          toggleMenu();
        }
      } );
    }

    function toggleMenu() {
      if( isOpen ) {
        classie.remove( bodyEl, 'show-menu' );
      }
      else {
        classie.add( bodyEl, 'show-menu' );
      }
      isOpen = !isOpen;
    }

    inits();


    //typed js
    $(".typed").typed({
        strings: ["My Name is M.Reza", "I'm a Web Designer", "Love Simplicity"],
        typeSpeed: 100,
        backDelay: 900,
        // loop
        loop: true
    });

    //owl carousel
    $('.owl-carousel').owlCarousel({
      autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 1,
      itemsDesktop : [1199,1],
      itemsDesktopSmall : [979,1],
      itemsTablet : [768,1],
      itemsMobile : [479,1],

      // CSS Styles
      baseClass : "owl-carousel",
      theme : "owl-theme"
    });

    $('.owl-carousel2').owlCarousel({
      autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 1,
      itemsDesktop : [1199,1],
      itemsDesktopSmall : [979,1],
      itemsTablet : [768,1],
      itemsMobile : [479,1],
      autoPlay : false,

      // CSS Styles
      baseClass : "owl-carousel",
      theme : "owl-theme"
    });

    //contact
    $('input').blur(function() {

      // check if the input has any value (if we've typed into it)
      if ($(this).val())
        $(this).addClass('used');
      else
        $(this).removeClass('used');
    });

    //pop up porfolio
    $('.portfolio-image li a').magnificPopup({
      type: 'image',
      gallery: {
        enabled: true
      }
      // other options
    });
    
    //Skill
    jQuery('.skillbar').each(function() {
      jQuery(this).appear(function() {
        jQuery(this).find('.count-bar').animate({
          width:jQuery(this).attr('data-percent')
        },3000);
        var percent = jQuery(this).attr('data-percent');
        jQuery(this).find('.count').html('<span>' + percent + '</span>');
      });
    }); 

  
  });
  
    
  //header
  function inits() {
    window.addEventListener('scroll', function(e){
        var distanceY = window.pageYOffset || document.documentElement.scrollTop,
            shrinkOn = 300,
            header = document.querySelector(".for-sticky");
        if (distanceY > shrinkOn) {
            classie.add(header,"opacity-nav");
        } else {<?php
			$json_string = file_get_contents("http://api.wunderground.com/api/2787748c5dc1150e/forecast10day/q/Indonesia/Kudus.json");
			$parsed_json = json_decode($json_string);
			$hari = $parsed_json->forecast->simpleforecast->forecastday[0]->date->weekday;
			$hari2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->weekday;
			$hari3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->weekday;
			$hari4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->weekday;
			$hari5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->weekday;
			$hari6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->weekday;
			$hari7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->weekday;
			$waktu = $parsed_json->forecast->simpleforecast->forecastday[0]->date->pretty;
			$waktu2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->pretty;
			$waktu3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->pretty;
			$waktu4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->pretty;
			$waktu5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->pretty;
			$waktu6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->pretty;
			$waktu7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->pretty;
			$cuaca = $parsed_json->forecast->simpleforecast->forecastday[0]->conditions;
			$cuaca2 = $parsed_json->forecast->simpleforecast->forecastday[1]->conditions;
			$cuaca3 = $parsed_json->forecast->simpleforecast->forecastday[2]->conditions;
			$cuaca4 = $parsed_json->forecast->simpleforecast->forecastday[3]->conditions;
			$cuaca5 = $parsed_json->forecast->simpleforecast->forecastday[4]->conditions;
			$cuaca6 = $parsed_json->forecast->simpleforecast->forecastday[5]->conditions;
			$cuaca7 = $parsed_json->forecast->simpleforecast->forecastday[6]->conditions;
			$icon = $parsed_json->forecast->simpleforecast->forecastday[0]->icon_url;
			$icon2 = $parsed_json->forecast->simpleforecast->forecastday[1]->icon_url;
			$icon3 = $parsed_json->forecast->simpleforecast->forecastday[2]->icon_url;
			$icon4 = $parsed_json->forecast->simpleforecast->forecastday[3]->icon_url;
			$icon5 = $parsed_json->forecast->simpleforecast->forecastday[4]->icon_url;
			$icon6 = $parsed_json->forecast->simpleforecast->forecastday[5]->icon_url;
			$icon7 = $parsed_json->forecast->simpleforecast->forecastday[6]->icon_url;
			$fcttext_metric = $parsed_json->forecast->txt_forecast->forecastday[0]->fcttext_metric;
			$fcttext_metric2 = $parsed_json->forecast->txt_forecast->forecastday[2]->fcttext_metric;
			$fcttext_metric3 = $parsed_json->forecast->txt_forecast->forecastday[4]->fcttext_metric;
			$fcttext_metric4 = $parsed_json->forecast->txt_forecast->forecastday[6]->fcttext_metric;
			$fcttext_metric5 = $parsed_json->forecast->txt_forecast->forecastday[8]->fcttext_metric;
			$fcttext_metric6 = $parsed_json->forecast->txt_forecast->forecastday[10]->fcttext_metric;
			$fcttext_metric7 = $parsed_json->forecast->txt_forecast->forecastday[12]->fcttext_metric;
			$suhu1a =  $parsed_json->forecast->simpleforecast->forecastday[0]->high->celsius;
			$suhu1b =  $parsed_json->forecast->simpleforecast->forecastday[0]->low->celsius;
			$suhu2a =  $parsed_json->forecast->simpleforecast->forecastday[1]->high->celsius;
			$suhu2b =  $parsed_json->forecast->simpleforecast->forecastday[1]->low->celsius;
			$suhu3a =  $parsed_json->forecast->simpleforecast->forecastday[2]->high->celsius;
			$suhu3b =  $parsed_json->forecast->simpleforecast->forecastday[2]->low->celsius;
			$suhu4a =  $parsed_json->forecast->simpleforecast->forecastday[3]->high->celsius;
			$suhu4b =  $parsed_json->forecast->simpleforecast->forecastday[3]->low->celsius;
			$suhu5a =  $parsed_json->forecast->simpleforecast->forecastday[4]->high->celsius;
			$suhu5b =  $parsed_json->forecast->simpleforecast->forecastday[4]->low->celsius;
			$suhu6a =  $parsed_json->forecast->simpleforecast->forecastday[5]->high->celsius;
			$suhu6b =  $parsed_json->forecast->simpleforecast->forecastday[5]->low->celsius;
			$suhu7a =  $parsed_json->forecast->simpleforecast->forecastday[6]->high->celsius;
			$suhu7b =  $parsed_json->forecast->simpleforecast->forecastday[6]->low->celsius;
			
			echo
"<b>Informasi Cuaca Wilayah Kudus : </b><br>
-------------------------------------------------- <br>
$hari, $waktu <br>
-------------------------------------------------- <br>
Cuaca : $cuaca <img src = '$icon'> <br>
Keterangan cuaca : $fcttext_metric <br>
High : $suhu1a <sup>O</sup> C <br>
Low : $suhu1b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari2, $waktu2 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca2 <img src = '$icon2'> <br>
Keterangan cuaca : $fcttext_metric2 <br>
High : $suhu1b <sup>O</sup> C <br>
Low : $suhu2b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari3, $waktu3 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca3 <img src = '$icon3'> <br>
Keterangan cuaca : $fcttext_metric3 <br>
High : $suhu3a <sup>O</sup> C <br>
Low : $suhu3b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari4, $waktu4 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca4 <img src = '$icon4'> <br>
Keterangan cuaca : $fcttext_metric4 <br>
High : $suhu4a <sup>O</sup> C <br>
Low : $suhu4b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari5, $waktu5 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca5 <img src = '$icon5'> <br>
Keterangan cuaca : $fcttext_metric5 <br>
High : $suhu5a <sup>O</sup> C <br>
Low : $suhu5b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari6, $waktu6 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca6 <img src = '$icon6'> <br>
Keterangan cuaca : $fcttext_metric6 <br>
High : $suhu6a <sup>O</sup> C <br>
Low : $suhu6b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari7, $waktu7 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca7 <img src = '$icon7'> <br>
Keterangan cuaca : $fcttext_metric7 <br>
High : $suhu7a <sup>O</sup> C <br>
Low : $suhu7b <sup>O</sup> C <br>


\n";


?>
?>
            if (classie.has(header,"opacity-nav")) {
                classie.remove(header,"opacity-nav");
            }
          }
      });
    }

  window.onload = inits();

  //nav-active
  function onScroll(event){
    var scrollPosition = $(document).scrollTop();
    $('.menu-list a').each(function () {
      var currentLink = $(this);
      var refElement = $(currentLink.attr("href"));
      if (refElement.position().top <= scrollPosition && refElement.position().top + refElement.height() > scrollPosition) {
        $('.menu-list a').removeClass("active");
        currentLink.addClass("active");
      }
      else{
        currentLink.removeClass("active");
      }
    });
  }

})(jQuery);