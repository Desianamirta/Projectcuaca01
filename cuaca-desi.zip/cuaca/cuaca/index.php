<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>THE WEATHER</title>
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta content="Bodo - Simple One Page Personal" name="description">
    <meta content="BdgPixel" name="author">
    <!--Fav-->
    <link href="images/icon.png" rel="shortcut icon">
    
    <!--styles-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    
    <!--fonts google-->
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
    
    <!--[if lt IE 9]>
       <script type="text/javascript" src="js/html5shiv.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <!--PRELOADER-->
    <div id="preloader">
      <div id="status">
        <img alt="logo" src="images/icon.png">
      </div>
    </div>
    <!--/.PRELOADER END-->

    <!--HEADER -->
    <div class="header">
      <div class="for-sticky">
        <!--LOGO-->
        <div class="col-md-2 col-xs-6 logo">
          <a href="index.html"><img alt="logo" class="logo-nav" src="images/icon.png"></a>
        </div>
        <!--/.LOGO END-->
      </div>
      <div class="menu-wrap">
        <nav class="menu">
          <div class="menu-list">
            <a data-scroll="" href="#home" class="active">
              <span>Home</span>
            </a>
            <a data-scroll="" href="#about">
              <span>About</span>
            </a>
			<a data-scroll="" href="#cuacaindo">
              <span>Cuaca di Wilayah Kudus</span>
            </a>
			 <a data-scroll="" href="#share">
              <span>Share</span>
            </a>
     
          </div>
        </nav>
        <button class="close-button" id="close-button">Close Menu</button>
      </div>
      <button class="menu-button" id="open-button">
        <span></span>
        <span></span>
        <span></span>
      </button><!--/.for-sticky-->
    </div>
    <!--/.HEADER END-->
    
    <!--CONTENT WRAP-->
    <div class="content-wrap">
      <!--CONTENT-->
      <div class="content">
        <!--HOME-->
        <section id="home">
          <div class="container">
            <div class="row">
              <div class="wrap-hero-content">
                  <div class="hero-content">
                    <!<h1>Welcome to</h1><br>
					<br>
<div>
<p align='center'><span style="font-size:24px;"></span>
<span style="color:#aec62c;font-size:24px;">"THE WEATHER"</span></p>
</div>
<br>
<div align='center'>

<?php
date_default_timezone_set("Asia/Jakarta");

?>
<script type="text/javascript">
    var detik = <?php echo date('s'); ?>;
    var menit = <?php echo date('i'); ?>;
    var jam   = <?php echo date('H'); ?>;
     
    function clock()
    {
        if (detik!=0 && detik%60==0) {
            menit++;
            detik=0;
        }
        second = detik;
         
        if (menit!=0 && menit%60==0) {
            jam++;
            menit=0;
        }
        minute = menit;
         
        if (jam!=0 && jam%24==0) {
            jam=0;
        }
        hour = jam;
         
        if (detik<10){
            second='0'+detik;
        }
        if (menit<10){
            minute='0'+menit;
        }
         
        if (jam<10){
            hour='0'+jam;
        }
        waktu = hour+':'+minute+':'+second;
         
        document.getElementById("clock").innerHTML = waktu;
        detik++;
    }
 
    setInterval(clock,1000);
</script>
<div style="text-align:center;">
    <h2 id="clock">
</div>
</div>
                    <span class="typed"></span>
                  </div>
              </div>
			  
              <div class="mouse-icon margin-20">
                <div class="scroll"></div>
              </div>
            </div>
          </div>
		  
        </section>
        <!--/.HOME END-->

        <!--ABOUT-->
        <section id="about">
          <div class="col-md-6 col-xs-12 no-pad">
            <div class="bg-about"></div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12 white-col">
            <div class="row">
              <!--OWL CAROUSEL2-->
              <div class="owl-carousel2">
                <div class="col-md-12">
                  <div class="wrap-about">
                    <div class="w-content">
                      <p class="head-about"> <b>Cuaca Hujann</b>  <img alt="signature" src="images/rain.gif"></p> 
                      <p  align="justify">Cuaca hujan artinya turunnya titik-titik air dari udara. Cuaca hujan terjadi diawali dari air laut yang menguap dan uap air tersebut mengembun karena udara yang dingin.
					  Uap air yang mengembun membentuk butiran air yang saling berkumpul hingga membentuk awan. Setelah butiran air yang terbentuk bertambah besar, maka akan jatuh sebagai hujan.</p>
                      
                      <!--<h5 class="name">
                        Desiana Mirta Sari
                      </h5>-->
                     <!-- <img alt="signature" src="images/cuaca.png">-->
                    </div>
                  </div>
                </div>
				
				  <div class="col-md-12">
                  <div class="wrap-about">
                    <div class="w-content">
                      <p class="head-about"> <b>Cuaca Berawan</b>  <img alt="signature" src="images/partlycloudy.gif"></p> 
                     <p  align="justify"> Cuaca berawan adalah cuaca yang menunjukkan bahwa di langit banyak terdapat awan. Awan merupakan kumpulan uap air yang terdapat di udara.
					  Uap air ini berasal dari air kolam, air danau, air laut, serta air sungai yang naik ke atas dan bergabung dengan udara karena pengaruh panas matahari. </p>
                      
                      <!--<h5 class="name">
                        Desiana Mirta Sari
                      </h5>-->
                     <!-- <img alt="signature" src="images/cuaca.png">-->
                    </div>
                  </div>
                </div>
				
				  <div class="col-md-12">
                  <div class="wrap-about">
                    <div class="w-content">
                      <p class="head-about"> <b>Cuaca Dingin</b>  <img alt="signature" src="images/snow.gif"></p>
                     <p  align="justify"> Cuaca dingin berarti udara terasa dingin. Pada cuaca dingin, suhu udara amat rendah.</p>
                      
                      <!--<h5 class="name">
                        Desiana Mirta Sari
                      </h5>-->
                     <!-- <img alt="signature" src="images/cuaca.png">-->
                    </div>
                  </div>
                </div>
				  <div class="col-md-12">
                  <div class="wrap-about">
                    <div class="w-content">
                     <p class="head-about"> <b>Cuaca Cerah</b>  <img alt="signature" src="images/cerah.gif"></p>
							<p  align="justify">Cuaca cerah artinya langit terang, tidak berawan, dan cahaya matahari bersinar terang. Pada saat cuaca cerah udara terasa hangat.
							Jika cuaca cerah, manusia dapat melakukan aktivitasnya dengan lebih nyaman. </p>
                      
                      <!--<h5 class="name">
                        Desiana Mirta Sari
                      </h5>-->
                     <!-- <img alt="signature" src="images/cuaca.png">-->
                    </div>
                  </div>
                </div>
				
				  <div class="col-md-12">
                  <div class="wrap-about">
                    <div class="w-content">
                     <p class="head-about"> <b>Cuaca Panas</b>  <img alt="signature" src="images/sunny.gif"></p>
							<p  align="justify">Cuaca panas berarti matahari bersinar terang dan udara terasa panas. Suhu di dataran rendah umumnya berbeda dengan suhu di dataran tinggi. Bila kita berada di dataran rendah, maka udaranya akan terasa panas.
							Sebaliknya, jika kita berada di dataran tinggi, maka udaranya akan terasa sejuk. </p>
                      
                      <!--<h5 class="name">
                        Desiana Mirta Sari
                      </h5>-->
                     <!-- <img alt="signature" src="images/cuaca.png">-->
                    </div>
                  </div>
                </div>

              <!--/.OWL CAROUSEL2 END-->
            </div>
          </div>
		  
        </section>
        <!--/.ABOUT END-->
		

 <!--CUACA-->
        <section id="cuacaindo">
          <div class="container">
            <div class="row wrap-testimonial">
              <div class="col-md-10 col-md-offset-1">
                <div class="owl-carousel">
				
				  <div class="list-testimonial">
                    <div class="content-testimonial">
                      <h3 class="testi"> WILAYAH KUDUS</h3> <img alt="signature" src="images/kudus.jpg"> <br>
					  <p> Berikut ini prakiraan kondisi cuaca di wilayah Kudus saat ini bersama dengan perkiraan cuaca untuk 7 hari kedepan </p>
                    </div>
                  </div>
				
                  <div class="list-testimonial">
                    <div class="content-testimonial">
                     <h3 class="testi"> KUDUS </h3>
<pre>
<?php
			$json_string = file_get_contents("http://api.wunderground.com/api/2787748c5dc1150e/forecast10day/q/Indonesia/Kudus.json");
			$parsed_json = json_decode($json_string);
			$hari = $parsed_json->forecast->simpleforecast->forecastday[0]->date->weekday;
			$hari2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->weekday;
			$hari3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->weekday;
			$hari4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->weekday;
			$hari5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->weekday;
			$hari6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->weekday;
			$hari7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->weekday;
			$waktu = $parsed_json->forecast->simpleforecast->forecastday[0]->date->pretty;
			$waktu2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->pretty;
			$waktu3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->pretty;
			$waktu4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->pretty;
			$waktu5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->pretty;
			$waktu6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->pretty;
			$waktu7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->pretty;
			$cuaca = $parsed_json->forecast->simpleforecast->forecastday[0]->conditions;
			$cuaca2 = $parsed_json->forecast->simpleforecast->forecastday[1]->conditions;
			$cuaca3 = $parsed_json->forecast->simpleforecast->forecastday[2]->conditions;
			$cuaca4 = $parsed_json->forecast->simpleforecast->forecastday[3]->conditions;
			$cuaca5 = $parsed_json->forecast->simpleforecast->forecastday[4]->conditions;
			$cuaca6 = $parsed_json->forecast->simpleforecast->forecastday[5]->conditions;
			$cuaca7 = $parsed_json->forecast->simpleforecast->forecastday[6]->conditions;
			$icon = $parsed_json->forecast->simpleforecast->forecastday[0]->icon_url;
			$icon2 = $parsed_json->forecast->simpleforecast->forecastday[1]->icon_url;
			$icon3 = $parsed_json->forecast->simpleforecast->forecastday[2]->icon_url;
			$icon4 = $parsed_json->forecast->simpleforecast->forecastday[3]->icon_url;
			$icon5 = $parsed_json->forecast->simpleforecast->forecastday[4]->icon_url;
			$icon6 = $parsed_json->forecast->simpleforecast->forecastday[5]->icon_url;
			$icon7 = $parsed_json->forecast->simpleforecast->forecastday[6]->icon_url;
			$fcttext_metric = $parsed_json->forecast->txt_forecast->forecastday[0]->fcttext_metric;
			$fcttext_metric2 = $parsed_json->forecast->txt_forecast->forecastday[2]->fcttext_metric;
			$fcttext_metric3 = $parsed_json->forecast->txt_forecast->forecastday[4]->fcttext_metric;
			$fcttext_metric4 = $parsed_json->forecast->txt_forecast->forecastday[6]->fcttext_metric;
			$fcttext_metric5 = $parsed_json->forecast->txt_forecast->forecastday[8]->fcttext_metric;
			$fcttext_metric6 = $parsed_json->forecast->txt_forecast->forecastday[10]->fcttext_metric;
			$fcttext_metric7 = $parsed_json->forecast->txt_forecast->forecastday[12]->fcttext_metric;
			$suhu1a =  $parsed_json->forecast->simpleforecast->forecastday[0]->high->celsius;
			$suhu1b =  $parsed_json->forecast->simpleforecast->forecastday[0]->low->celsius;
			$suhu2a =  $parsed_json->forecast->simpleforecast->forecastday[1]->high->celsius;
			$suhu2b =  $parsed_json->forecast->simpleforecast->forecastday[1]->low->celsius;
			$suhu3a =  $parsed_json->forecast->simpleforecast->forecastday[2]->high->celsius;
			$suhu3b =  $parsed_json->forecast->simpleforecast->forecastday[2]->low->celsius;
			$suhu4a =  $parsed_json->forecast->simpleforecast->forecastday[3]->high->celsius;
			$suhu4b =  $parsed_json->forecast->simpleforecast->forecastday[3]->low->celsius;
			$suhu5a =  $parsed_json->forecast->simpleforecast->forecastday[4]->high->celsius;
			$suhu5b =  $parsed_json->forecast->simpleforecast->forecastday[4]->low->celsius;
			$suhu6a =  $parsed_json->forecast->simpleforecast->forecastday[5]->high->celsius;
			$suhu6b =  $parsed_json->forecast->simpleforecast->forecastday[5]->low->celsius;
			$suhu7a =  $parsed_json->forecast->simpleforecast->forecastday[6]->high->celsius;
			$suhu7b =  $parsed_json->forecast->simpleforecast->forecastday[6]->low->celsius;
			
			echo
"<b>Informasi Cuaca Wilayah Kudus : </b><br>
-------------------------------------------------- <br>
$hari, $waktu <br>
-------------------------------------------------- <br>
Cuaca : $cuaca <img src = '$icon'> <br>
Keterangan cuaca : $fcttext_metric <br>
High : $suhu1a <sup>O</sup> C <br>
Low : $suhu1b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari2, $waktu2 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca2 <img src = '$icon2'> <br>
Keterangan cuaca : $fcttext_metric2 <br>
High : $suhu1b <sup>O</sup> C <br>
Low : $suhu2b <sup>O</sup> C <br>

\n";


?>
</pre>
                    </div>
                  </div>
                 
                  <div class="list-testimonial">
                    <div class="content-testimonial">
                      <h3 class="testi"> KUDUS</h3>
<pre>
<?php
			$json_string = file_get_contents("http://api.wunderground.com/api/2787748c5dc1150e/forecast10day/q/Indonesia/Kudus.json");
			$parsed_json = json_decode($json_string);
			$hari = $parsed_json->forecast->simpleforecast->forecastday[0]->date->weekday;
			$hari2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->weekday;
			$hari3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->weekday;
			$hari4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->weekday;
			$hari5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->weekday;
			$hari6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->weekday;
			$hari7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->weekday;
			$waktu = $parsed_json->forecast->simpleforecast->forecastday[0]->date->pretty;
			$waktu2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->pretty;
			$waktu3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->pretty;
			$waktu4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->pretty;
			$waktu5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->pretty;
			$waktu6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->pretty;
			$waktu7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->pretty;
			$cuaca = $parsed_json->forecast->simpleforecast->forecastday[0]->conditions;
			$cuaca2 = $parsed_json->forecast->simpleforecast->forecastday[1]->conditions;
			$cuaca3 = $parsed_json->forecast->simpleforecast->forecastday[2]->conditions;
			$cuaca4 = $parsed_json->forecast->simpleforecast->forecastday[3]->conditions;
			$cuaca5 = $parsed_json->forecast->simpleforecast->forecastday[4]->conditions;
			$cuaca6 = $parsed_json->forecast->simpleforecast->forecastday[5]->conditions;
			$cuaca7 = $parsed_json->forecast->simpleforecast->forecastday[6]->conditions;
			$icon = $parsed_json->forecast->simpleforecast->forecastday[0]->icon_url;
			$icon2 = $parsed_json->forecast->simpleforecast->forecastday[1]->icon_url;
			$icon3 = $parsed_json->forecast->simpleforecast->forecastday[2]->icon_url;
			$icon4 = $parsed_json->forecast->simpleforecast->forecastday[3]->icon_url;
			$icon5 = $parsed_json->forecast->simpleforecast->forecastday[4]->icon_url;
			$icon6 = $parsed_json->forecast->simpleforecast->forecastday[5]->icon_url;
			$icon7 = $parsed_json->forecast->simpleforecast->forecastday[6]->icon_url;
			$fcttext_metric = $parsed_json->forecast->txt_forecast->forecastday[0]->fcttext_metric;
			$fcttext_metric2 = $parsed_json->forecast->txt_forecast->forecastday[2]->fcttext_metric;
			$fcttext_metric3 = $parsed_json->forecast->txt_forecast->forecastday[4]->fcttext_metric;
			$fcttext_metric4 = $parsed_json->forecast->txt_forecast->forecastday[6]->fcttext_metric;
			$fcttext_metric5 = $parsed_json->forecast->txt_forecast->forecastday[8]->fcttext_metric;
			$fcttext_metric6 = $parsed_json->forecast->txt_forecast->forecastday[10]->fcttext_metric;
			$fcttext_metric7 = $parsed_json->forecast->txt_forecast->forecastday[12]->fcttext_metric;
			$suhu1a =  $parsed_json->forecast->simpleforecast->forecastday[0]->high->celsius;
			$suhu1b =  $parsed_json->forecast->simpleforecast->forecastday[0]->low->celsius;
			$suhu2a =  $parsed_json->forecast->simpleforecast->forecastday[1]->high->celsius;
			$suhu2b =  $parsed_json->forecast->simpleforecast->forecastday[1]->low->celsius;
			$suhu3a =  $parsed_json->forecast->simpleforecast->forecastday[2]->high->celsius;
			$suhu3b =  $parsed_json->forecast->simpleforecast->forecastday[2]->low->celsius;
			$suhu4a =  $parsed_json->forecast->simpleforecast->forecastday[3]->high->celsius;
			$suhu4b =  $parsed_json->forecast->simpleforecast->forecastday[3]->low->celsius;
			$suhu5a =  $parsed_json->forecast->simpleforecast->forecastday[4]->high->celsius;
			$suhu5b =  $parsed_json->forecast->simpleforecast->forecastday[4]->low->celsius;
			$suhu6a =  $parsed_json->forecast->simpleforecast->forecastday[5]->high->celsius;
			$suhu6b =  $parsed_json->forecast->simpleforecast->forecastday[5]->low->celsius;
			$suhu7a =  $parsed_json->forecast->simpleforecast->forecastday[6]->high->celsius;
			$suhu7b =  $parsed_json->forecast->simpleforecast->forecastday[6]->low->celsius;
			
			echo
"<b>Informasi Cuaca Wilayah Kudus : </b><br>
-------------------------------------------------- <br>
$hari3, $waktu3 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca3 <img src = '$icon3'> <br>
Keterangan cuaca : $fcttext_metric3 <br>
High : $suhu3a <sup>O</sup> C <br>
Low : $suhu3b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari4, $waktu4 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca4 <img src = '$icon4'> <br>
Keterangan cuaca : $fcttext_metric4 <br>
High : $suhu4a <sup>O</sup> C <br>
Low : $suhu4b <sup>O</sup> C <br>
\n";


?>
</pre>
                    </div>
                  </div>
				  
				                    <div class="list-testimonial">
                    <div class="content-testimonial">
                     <h3 class="testi"> KUDUS </h3>
<pre>
<?php
			$json_string = file_get_contents("http://api.wunderground.com/api/2787748c5dc1150e/forecast10day/q/Indonesia/Kudus.json");
			$parsed_json = json_decode($json_string);
			$hari = $parsed_json->forecast->simpleforecast->forecastday[0]->date->weekday;
			$hari2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->weekday;
			$hari3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->weekday;
			$hari4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->weekday;
			$hari5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->weekday;
			$hari6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->weekday;
			$hari7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->weekday;
			$waktu = $parsed_json->forecast->simpleforecast->forecastday[0]->date->pretty;
			$waktu2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->pretty;
			$waktu3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->pretty;
			$waktu4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->pretty;
			$waktu5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->pretty;
			$waktu6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->pretty;
			$waktu7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->pretty;
			$cuaca = $parsed_json->forecast->simpleforecast->forecastday[0]->conditions;
			$cuaca2 = $parsed_json->forecast->simpleforecast->forecastday[1]->conditions;
			$cuaca3 = $parsed_json->forecast->simpleforecast->forecastday[2]->conditions;
			$cuaca4 = $parsed_json->forecast->simpleforecast->forecastday[3]->conditions;
			$cuaca5 = $parsed_json->forecast->simpleforecast->forecastday[4]->conditions;
			$cuaca6 = $parsed_json->forecast->simpleforecast->forecastday[5]->conditions;
			$cuaca7 = $parsed_json->forecast->simpleforecast->forecastday[6]->conditions;
			$icon = $parsed_json->forecast->simpleforecast->forecastday[0]->icon_url;
			$icon2 = $parsed_json->forecast->simpleforecast->forecastday[1]->icon_url;
			$icon3 = $parsed_json->forecast->simpleforecast->forecastday[2]->icon_url;
			$icon4 = $parsed_json->forecast->simpleforecast->forecastday[3]->icon_url;
			$icon5 = $parsed_json->forecast->simpleforecast->forecastday[4]->icon_url;
			$icon6 = $parsed_json->forecast->simpleforecast->forecastday[5]->icon_url;
			$icon7 = $parsed_json->forecast->simpleforecast->forecastday[6]->icon_url;
			$fcttext_metric = $parsed_json->forecast->txt_forecast->forecastday[0]->fcttext_metric;
			$fcttext_metric2 = $parsed_json->forecast->txt_forecast->forecastday[2]->fcttext_metric;
			$fcttext_metric3 = $parsed_json->forecast->txt_forecast->forecastday[4]->fcttext_metric;
			$fcttext_metric4 = $parsed_json->forecast->txt_forecast->forecastday[6]->fcttext_metric;
			$fcttext_metric5 = $parsed_json->forecast->txt_forecast->forecastday[8]->fcttext_metric;
			$fcttext_metric6 = $parsed_json->forecast->txt_forecast->forecastday[10]->fcttext_metric;
			$fcttext_metric7 = $parsed_json->forecast->txt_forecast->forecastday[12]->fcttext_metric;
			$suhu1a =  $parsed_json->forecast->simpleforecast->forecastday[0]->high->celsius;
			$suhu1b =  $parsed_json->forecast->simpleforecast->forecastday[0]->low->celsius;
			$suhu2a =  $parsed_json->forecast->simpleforecast->forecastday[1]->high->celsius;
			$suhu2b =  $parsed_json->forecast->simpleforecast->forecastday[1]->low->celsius;
			$suhu3a =  $parsed_json->forecast->simpleforecast->forecastday[2]->high->celsius;
			$suhu3b =  $parsed_json->forecast->simpleforecast->forecastday[2]->low->celsius;
			$suhu4a =  $parsed_json->forecast->simpleforecast->forecastday[3]->high->celsius;
			$suhu4b =  $parsed_json->forecast->simpleforecast->forecastday[3]->low->celsius;
			$suhu5a =  $parsed_json->forecast->simpleforecast->forecastday[4]->high->celsius;
			$suhu5b =  $parsed_json->forecast->simpleforecast->forecastday[4]->low->celsius;
			$suhu6a =  $parsed_json->forecast->simpleforecast->forecastday[5]->high->celsius;
			$suhu6b =  $parsed_json->forecast->simpleforecast->forecastday[5]->low->celsius;
			$suhu7a =  $parsed_json->forecast->simpleforecast->forecastday[6]->high->celsius;
			$suhu7b =  $parsed_json->forecast->simpleforecast->forecastday[6]->low->celsius;
			
			echo
"<b>Informasi Cuaca Wilayah Kudus : </b><br>
-------------------------------------------------- <br>
$hari5, $waktu5 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca5 <img src = '$icon5'> <br>
Keterangan cuaca : $fcttext_metric5 <br>
High : $suhu5a <sup>O</sup> C <br>
Low : $suhu5b <sup>O</sup> C <br>

-------------------------------------------------- <br>
$hari6, $waktu6 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca6 <img src = '$icon6'> <br>
Keterangan cuaca : $fcttext_metric6 <br>
High : $suhu6a <sup>O</sup> C <br>
Low : $suhu6b <sup>O</sup> C <br>

\n";


?>
</pre>
                    </div>
                  </div>
				  
				  				                    <div class="list-testimonial">
                    <div class="content-testimonial">
                     <h3 class="testi"> KUDUS </h3>
<pre>
<?php
			$json_string = file_get_contents("http://api.wunderground.com/api/2787748c5dc1150e/forecast10day/q/Indonesia/Kudus.json");
			$parsed_json = json_decode($json_string);
			$hari = $parsed_json->forecast->simpleforecast->forecastday[0]->date->weekday;
			$hari2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->weekday;
			$hari3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->weekday;
			$hari4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->weekday;
			$hari5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->weekday;
			$hari6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->weekday;
			$hari7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->weekday;
			$waktu = $parsed_json->forecast->simpleforecast->forecastday[0]->date->pretty;
			$waktu2 = $parsed_json->forecast->simpleforecast->forecastday[1]->date->pretty;
			$waktu3 = $parsed_json->forecast->simpleforecast->forecastday[2]->date->pretty;
			$waktu4 = $parsed_json->forecast->simpleforecast->forecastday[3]->date->pretty;
			$waktu5 = $parsed_json->forecast->simpleforecast->forecastday[4]->date->pretty;
			$waktu6 = $parsed_json->forecast->simpleforecast->forecastday[5]->date->pretty;
			$waktu7 = $parsed_json->forecast->simpleforecast->forecastday[6]->date->pretty;
			$cuaca = $parsed_json->forecast->simpleforecast->forecastday[0]->conditions;
			$cuaca2 = $parsed_json->forecast->simpleforecast->forecastday[1]->conditions;
			$cuaca3 = $parsed_json->forecast->simpleforecast->forecastday[2]->conditions;
			$cuaca4 = $parsed_json->forecast->simpleforecast->forecastday[3]->conditions;
			$cuaca5 = $parsed_json->forecast->simpleforecast->forecastday[4]->conditions;
			$cuaca6 = $parsed_json->forecast->simpleforecast->forecastday[5]->conditions;
			$cuaca7 = $parsed_json->forecast->simpleforecast->forecastday[6]->conditions;
			$icon = $parsed_json->forecast->simpleforecast->forecastday[0]->icon_url;
			$icon2 = $parsed_json->forecast->simpleforecast->forecastday[1]->icon_url;
			$icon3 = $parsed_json->forecast->simpleforecast->forecastday[2]->icon_url;
			$icon4 = $parsed_json->forecast->simpleforecast->forecastday[3]->icon_url;
			$icon5 = $parsed_json->forecast->simpleforecast->forecastday[4]->icon_url;
			$icon6 = $parsed_json->forecast->simpleforecast->forecastday[5]->icon_url;
			$icon7 = $parsed_json->forecast->simpleforecast->forecastday[6]->icon_url;
			$fcttext_metric = $parsed_json->forecast->txt_forecast->forecastday[0]->fcttext_metric;
			$fcttext_metric2 = $parsed_json->forecast->txt_forecast->forecastday[2]->fcttext_metric;
			$fcttext_metric3 = $parsed_json->forecast->txt_forecast->forecastday[4]->fcttext_metric;
			$fcttext_metric4 = $parsed_json->forecast->txt_forecast->forecastday[6]->fcttext_metric;
			$fcttext_metric5 = $parsed_json->forecast->txt_forecast->forecastday[8]->fcttext_metric;
			$fcttext_metric6 = $parsed_json->forecast->txt_forecast->forecastday[10]->fcttext_metric;
			$fcttext_metric7 = $parsed_json->forecast->txt_forecast->forecastday[12]->fcttext_metric;
			$suhu1a =  $parsed_json->forecast->simpleforecast->forecastday[0]->high->celsius;
			$suhu1b =  $parsed_json->forecast->simpleforecast->forecastday[0]->low->celsius;
			$suhu2a =  $parsed_json->forecast->simpleforecast->forecastday[1]->high->celsius;
			$suhu2b =  $parsed_json->forecast->simpleforecast->forecastday[1]->low->celsius;
			$suhu3a =  $parsed_json->forecast->simpleforecast->forecastday[2]->high->celsius;
			$suhu3b =  $parsed_json->forecast->simpleforecast->forecastday[2]->low->celsius;
			$suhu4a =  $parsed_json->forecast->simpleforecast->forecastday[3]->high->celsius;
			$suhu4b =  $parsed_json->forecast->simpleforecast->forecastday[3]->low->celsius;
			$suhu5a =  $parsed_json->forecast->simpleforecast->forecastday[4]->high->celsius;
			$suhu5b =  $parsed_json->forecast->simpleforecast->forecastday[4]->low->celsius;
			$suhu6a =  $parsed_json->forecast->simpleforecast->forecastday[5]->high->celsius;
			$suhu6b =  $parsed_json->forecast->simpleforecast->forecastday[5]->low->celsius;
			$suhu7a =  $parsed_json->forecast->simpleforecast->forecastday[6]->high->celsius;
			$suhu7b =  $parsed_json->forecast->simpleforecast->forecastday[6]->low->celsius;
			
			echo
"<b>Informasi Cuaca Wilayah Kudus : </b><br>
-------------------------------------------------- <br>
$hari7, $waktu7 <br>
-------------------------------------------------- <br>
Cuaca : $cuaca7 <img src = '$icon7'> <br>
Keterangan cuaca : $fcttext_metric7 <br>
High : $suhu7a <sup>O</sup> C <br>
Low : $suhu7b <sup>O</sup> C <br>


\n";


?>
</pre>
                    </div>
                  </div>
				  
				  
                </div>
              </div>
            </div>
          </div>
          <div class="mask-testimonial"></div>
        </section>
        <!--/.CUACA END-->

				    <!--SHARE-->
        <section id="share" class="white-bg">
          <div class="container">
            <div class="row">
              <div class="col-md-3">
                <h3 class="title-small">
                  <span>SHARE FACEBOOK</span>
                </h3>
              <p class="content-detail">
                  Bagikan informasi tentang cuaca ini ke beberapa temanmu. . .
                </p>

              </div>
              <div class="col-md-9 content-right">
                <form>
				<div class="group">
                    <input required="" type="email"><span class="highlight"></span><span class="bar"></span><label>Email atau Telepon</label>
                  </div>
                  <div class="group">
                    <input required="" type="text"><span class="highlight"></span><span class="bar"></span><label>Password</label>
                  </div>

                  <input id="submit" name="submit" type="submit" value="Submit">
                </form>
              </div>
            </div>
          </div>
        </section>
        <!--/.SHARE END-->
	
		
		
        <!--FOOTER-->
        <footer>
          <div class="footer-top">
            <ul class="socials">
              <li class="facebook">
                <a href="#" data-hover="Facebook">Facebook</a>
              </li>
              <li class="instagram">
                <a href="#" data-hover="instagram">Instagram</a>
              </li>
              <li class="gplus">
                <a href="#" data-hover="Google +">Google +</a>
              </li>
            </ul>
          </div>

          <div class="footer-bottom">
            <div class="container">
              <div class="row">
                <a href="https://dcrazed.com/"><img src="images/logo-bottom.png" alt="crafted with love" class="center-block" /></a>
			 </div>
            </div>
          </div>
        </footer>
        <!--/.FOOTER-END-->

      <!--/.CONTENT END-->
      </div>
    <!--/.CONTENT-WRAP END-->
    </div>
    

    <script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="js/jquery.appear.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/classie.js" type="text/javascript"></script>
    <script src="js/owl.carousel.min.js" type="text/javascript"></script>
    <script src="js/jquery.magnific-popup.min.js" type="text/javascript"></script>
    <script src="js/masonry.pkgd.min.js" type="text/javascript"></script>
    <script src="js/masonry.js" type="text/javascript"></script>
    <script src="js/smooth-scroll.min.js" type="text/javascript"></script>
    <script src="js/typed.js" type="text/javascript"></script>
    <script src="js/main.js" type="text/javascript"></script>
  </body>
</html>